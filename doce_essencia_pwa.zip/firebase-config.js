// Preencha aqui quando configurar o Firebase
export const firebaseConfig = {
  apiKey: "",
  authDomain: "",
  projectId: ""
};
